package resources;

public enum APIResources {
	
	
	AddTransaction("/oneaccums/api/addAccumTransactions");
	private String resource;
	
	/*
	 * When we are calling constructor we are loading value of the resources mentioned above
	 */
	APIResources(String resource) {
		this.resource=resource;
			
	}
	
	public String getResource() {
		return resource;
	}
	
	

}
